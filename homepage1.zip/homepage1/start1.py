from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# 게시글 정보를 저장할 리스트 (임시로 메모리에서 관리)
posts = []

@app.route('/')
def index():
    return render_template('noticeboard.html', posts=posts)  # 게시글 목록을 템플릿으로 전달

# 게시글 작성 페이지
@app.route('/new', methods=['GET', 'POST'])
def new_post():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        
        if title and content:
            # 게시글 정보를 리스트에 추가
            posts.append({'title': title, 'content': content})
            return redirect(url_for('index'))  # 게시글 작성 후 목록 페이지로 리디렉션
        else:
            return "제목과 내용을 모두 입력해 주세요."

    return render_template('newpost.html')  # GET 요청 시 게시글 작성 폼 제공

# 게시글 상세보기 페이지 (이제 postlist로 변경)
@app.route('/postlist/<int:post_id>')
def postlist(post_id):
    if post_id < len(posts):
        post = posts[post_id]
        return render_template('postlist.html', post=post)  # 템플릿 이름을 postlist.html로 변경
    else:
        return "존재하지 않는 게시글입니다."

if __name__ == '__main__':
    app.run(debug=True)
