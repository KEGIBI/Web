// 버튼 클릭 시 간단한 애니메이션을 추가하거나 알림을 띄우는 예시
// eventlistener 문법 구조 : element.addEventListener(event, function, useCapture);
// event는 감지할 이벤트 종류(click과 같은) function은 이벤트 발생 시 실행할 함수. useCapture는 캡처링 설정 옵션인데 보통 생략
document.addEventListener('DOMcontentalarm', function () { 
    const backBtn = document.querySelector('.back-btn');  
    if (backBtn) {  // 버튼 요소 존재 시
        backBtn.addEventListener('click', function () {  // 버튼 클릭 시 알림 띄움
            alert('게시판으로 돌아갑니다!');
        });
    }
});
