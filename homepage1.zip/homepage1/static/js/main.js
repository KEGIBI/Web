// 버튼 클릭 시 간단한 애니메이션을 추가하거나 알림을 띄우는 예시
document.addEventListener('DOMContentLoaded', function () {
    const backBtn = document.querySelector('.back-btn');
    if (backBtn) {
        backBtn.addEventListener('click', function () {
            alert('게시판으로 돌아갑니다!');
        });
    }
});
